function uploadBox(){
  'https://www.box.net/api/1.0/rest?action=get_ticket&api_key='+api_key

}
