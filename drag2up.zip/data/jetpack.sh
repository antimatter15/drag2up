node compile.js > magic.js
cat ../lib/mainsrc.js magic.js > ../lib/main.js
rm magic.js
